import 'package:flutter/material.dart';

class ReviewRatingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Review and Rating for Worker"),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              // Profile action
            },
          ),
        ],
      ),
      body: Expanded(
        child: ListView.builder(
          itemCount: 5, // Number of reviews; replace with actual data
          itemBuilder: (context, index) {
            return ListTile(
              leading: Container(
                width: 60,
                height: 60,
                color: Colors.grey[300],
                child: Center(child: Text("Photo")), // Placeholder for worker's photo
              ),
              title: Text("Worker's Name"),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: List.generate(5, (i) => Icon(Icons.star, color: i < 4 ? Colors.amber : Colors.grey)), // Placeholder star rating
                  ),
                  SizedBox(height: 4),
                  Text("Review text goes here"), // Placeholder for review text
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

