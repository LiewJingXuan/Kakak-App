import 'package:flutter/material.dart';
import 'customer_dashboard.dart';
import 'services_page.dart';
import 'review_rating_page.dart';
import 'booking_history_page.dart';
import 'chat_with_admin_page.dart';

class MainNavigation extends StatefulWidget {
  final int initialTabIndex;

  MainNavigation({this.initialTabIndex = 2});

  @override
  MainNavigationState createState() => MainNavigationState();
}

class MainNavigationState extends State<MainNavigation> {
  int selectedIndex = 2; 
  
  @override
  void initState(){
    super.initState();
    selectedIndex = widget.initialTabIndex;
  }

  final List<Widget> pages = [
    ServicesPage(),
    ReviewRatingPage(),
    CustomerDashboard(),
    BookingHistoryPage(),
    ChatWithAdminPage(),
  ];

  void onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: selectedIndex,
        children: pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedIndex,
        selectedIconTheme: IconThemeData(color: Colors.black, size: 30), // Selected icon in black and larger size
        unselectedIconTheme: IconThemeData(color: Colors.grey, size: 24), // Unselected icons in grey
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Services'),
          BottomNavigationBarItem(icon: Icon(Icons.thumb_up), label: 'Reviews'),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.add,
              color: selectedIndex == 2 ? Colors.black : Colors.grey, // Make black only when selected
              size: 36,
            ),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: 'Articles'),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: 'Chat'),
        ],
        onTap: onItemTapped,
      ),
    );
  }
}