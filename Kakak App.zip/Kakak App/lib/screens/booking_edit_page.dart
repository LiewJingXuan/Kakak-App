import 'package:flutter/material.dart';

class BookingEditPage extends StatefulWidget {
  final Map<String, dynamic> booking;

  BookingEditPage({required this.booking});

  @override
  _BookingEditPageState createState() => _BookingEditPageState();
}

class _BookingEditPageState extends State<BookingEditPage> {
  late TextEditingController _dateController;

  @override
  void initState() {
    super.initState();
    _dateController = TextEditingController(text: widget.booking["date"]);
  }

  @override
  void dispose() {
    _dateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Booking"),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              // Profile action
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              color: Colors.grey[300],
              child: Center(child: Icon(Icons.image)), // Placeholder for worker's profile picture
            ),
            SizedBox(height: 16),
            Text("Title: ${widget.booking["title"]}"),
            Text("Status: ${widget.booking["status"]}"),
            SizedBox(height: 20),
            TextField(
              controller: _dateController,
              decoration: InputDecoration(labelText: "Booking Date"),
              readOnly: widget.booking["status"] == "Completed", // Disable if status is Completed
              onTap: widget.booking["status"] == "Pending"
                  ? () async {
                      DateTime? newDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                      );
                      if (newDate != null) {
                        setState(() {
                          _dateController.text = newDate.toLocal().toString().split(' ')[0];
                        });
                      }
                    }
                  : null,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: widget.booking["status"] == "Pending"
                  ? () {
                      // Save changes
                      // Perform save action and navigate back
                      Navigator.pop(context);
                    }
                  : null, // Disable if status is Completed
              child: Text("Save"),
            ),
          ],
        ),
      ),
    );
  }
}
