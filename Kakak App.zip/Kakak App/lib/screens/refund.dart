import 'package:flutter/material.dart';
import 'complain.dart';
import 'login.dart';
import 'manageUser.dart';

class RefundPage extends StatelessWidget {
  const RefundPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginPage()));
          },
        ),
        title: const Text('Refund'),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle),
            onPressed: () {
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: customers.length,
              itemBuilder: (context, index) {
                final customer = customers[index];
                final TextEditingController refundController = TextEditingController();

                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(customer.photoUrl), // 用户头像
                  ),
                  title: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(customer.name),
                          const Icon(Icons.person), // 客户图标
                        ],
                      ),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: refundController,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                labelText: 'Refund Amount(ex: 100.00)',
                                border: OutlineInputBorder(),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          ElevatedButton(
                            onPressed: () {
                              // 触发退款操作
                              String refundAmount = refundController.text;
                              processRefund(customer.userId, refundAmount);
                            },
                            child: const Text('Refund'),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          BottomNavigationBar(
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.people),
                label: 'User',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.sentiment_satisfied),
                label: 'Complaint',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.add),
                label: 'Edit',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.payment),
                label: 'Reufund',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.description),
                label: 'Report',
              ),
            ],
            onTap: (index) {
              switch (index) {
                case 0:
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ManageUsersPage(),
                    ),
                  );
                  break;
                case 1:
                  // 跳转到反馈页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ComplaintsPage(),
                    ),
                  );
                  break;
                case 2:
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      //
                      builder: (context) => const ComplaintsPage(),
                    ),
                  );
                  break;
                case 3:
                  break;
                case 4:
                  // 跳转到文档页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ComplaintsPage(),
                    ),
                  );
                  break;
              }
            },
          ),
        ],
      ),
    );
  }

  // 模拟退款操作
  void processRefund(String userId, String amount) {
    // 实际应用中，可将退款数据发送至服务器
    print('用户ID: $userId, 退款金额: $amount');
  }
}

// 模拟客户数据
class Customer {
  final String userId;
  final String name;
  final String photoUrl;

  Customer({
    required this.userId,
    required this.name,
    required this.photoUrl,
  });
}

// 示例客户数据
final List<Customer> customers = [
  Customer(userId: '1', name: 'John Doe', photoUrl: 'https://via.placeholder.com/150'),
  Customer(userId: '2', name: 'Jane Smith', photoUrl: 'https://via.placeholder.com/150'),
  Customer(userId: '3', name: 'Alice Brown', photoUrl: 'https://via.placeholder.com/150'),
];
