import 'package:flutter/material.dart';
import 'booking_edit_page.dart';

class BookingDetailPage extends StatelessWidget {
  final Map<String, dynamic> booking;

  BookingDetailPage({required this.booking});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Booking Details"),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              // Profile action
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              color: Colors.grey[300],
              child: Center(child: Icon(Icons.image)), // Placeholder for worker's profile picture
            ),
            SizedBox(height: 16),
            Text("Title: ${booking["title"]}"),
            Text("Date: ${booking["date"]}"),
            Text("Status: ${booking["status"]}"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: booking["status"] == "Pending"
                  ? () {
                      
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BookingEditPage(booking: booking),
                        ),
                      );
                    }
                  : null,
              child: Text("Edit"),
            ),
          ],
        ),
      ),
    );
  }
}
