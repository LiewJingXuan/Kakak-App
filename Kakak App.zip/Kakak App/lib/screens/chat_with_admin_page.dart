import 'package:flutter/material.dart';

class ChatWithAdminPage extends StatefulWidget {
  @override
  ChatWithAdminPageState createState() => ChatWithAdminPageState();
}

class ChatWithAdminPageState extends State<ChatWithAdminPage> {
  final TextEditingController messageController = TextEditingController();
  final List<String> messages = [];

  void _sendMessage() {
    if (messageController.text.trim().isNotEmpty) {
      setState(() {
        messages.add(messageController.text.trim());
        messageController.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chat with Admin"),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: messages.length, // Corrected from `_messages`
              itemBuilder: (context, index) {
                return Align(
                  alignment: Alignment.centerLeft, // Adjust alignment as needed
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 4),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(messages[index]),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: messageController,
                    decoration: InputDecoration(
                      hintText: "Type your message...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      contentPadding: EdgeInsets.symmetric(horizontal: 12),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage, // Corrected method reference
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
