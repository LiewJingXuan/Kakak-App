import 'package:flutter/material.dart';
import 'household_chores_page.dart';
import 'day_care_page.dart';
import 'package:mae_assignment/widgets/service_icon.dart';

// Main Dashboard Page

class CustomerDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Customer Dashboard"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        actions: [
          IconButton(
            icon: Image.asset('assets/blank_profile.png', width: 30),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Center(
              child: Column(
                children: [
                  Image.asset('assets/Kakak_Logo.png', height: 150),
                ],
              ),
            ),
            SizedBox(height: 20),
            Text("Our Services", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text("Please Choose One Service", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ServiceIcon(
                  imagePath: 'assets/household_chores1.jpg',
                  label: "Household Chores",
                  iconSize: 120,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HouseholdChoresPage()),
                    );
                  },
                ),
                ServiceIcon(
                  imagePath: 'assets/daycare.jpg',
                  label: "Day Care",
                  iconSize: 120,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => DayCarePage()),
                    );
                  },
                ),
              ],
            ),
            SizedBox(height: 30),
            ListTile(
              title: Text("Terms and Conditions"),
              onTap: () {},
            ),
            Divider(),
            ListTile(
              title: Text("FAQ sections"),
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}