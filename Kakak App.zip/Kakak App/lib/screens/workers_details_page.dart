import 'package:flutter/material.dart';
import 'booking_page.dart';

class WorkerDetailsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text("Worker Details"),
        actions: [
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () {
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Worker Photo and Details
            Center(
              child: Column(
                children: [
                  Container(
                    width: 150,
                    height: 150,
                    color: Colors.grey[300], // Placeholder for worker's photo
                    child: Center(child: Text("Worker's Photo")),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Worker's Name",
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Worker's description and details go here.",
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            // Reviews Section
            Text(
              "Reviews",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.all(8.0),
              child: Column(
                children: [
                  ReviewTile(),
                  ReviewTile(),
                  ReviewTile(),
                  SizedBox(height: 10),
                  // Overall Rating
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Overall Rating:"),
                      Row(
                        children: List.generate(
                          4,
                          (index) => Icon(Icons.star, color: Colors.amber),
                        )..add(Icon(Icons.star_border)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Spacer(),
            // Start Booking Button
            Center(
              child: ElevatedButton(
                onPressed: () {
                  // Start Booking action
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => BookingPage()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                ),
                child: Text("Start Booking"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Widget for each review
class ReviewTile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.grey[300], // Placeholder for user's photo
        child: Icon(Icons.person),
      ),
      title: Text("User's Name"),
      subtitle: Text("User's review text goes here."),
    );
  }
}