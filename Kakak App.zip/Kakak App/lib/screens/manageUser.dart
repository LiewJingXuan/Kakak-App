import 'package:flutter/material.dart';
import 'complain.dart';
import 'login.dart';
import 'refund.dart';

class ManageUsersPage extends StatelessWidget {
  const ManageUsersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginPage()));
          },
        ),
        title: const Text('Manage User'),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle),
            onPressed: () {
              // 当前admin的头像
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: users.length,
              itemBuilder: (context, index) {
                final user = users[index];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(user.photoUrl), // 用户头像
                  ),
                  title: Row(
                    children: [
                      Text(user.name),
                      if (user.isCustomer)
                        const Icon(Icons.person), // 客户图标
                    ],
                  ),
                  subtitle: user.isCustomer
                      ? null
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(user.description ?? ''),
                            Row(
                              children: List.generate(5, (starIndex) {
                                return Icon(
                                  starIndex < user.rating
                                      ? Icons.star
                                      : Icons.star_border,
                                  size: 20,
                                  color: Colors.amber,
                                );
                              }),
                            ),
                          ],
                        ),
                  onTap: () {
                    // 跳转到用户的账号页面
                  },
                );
              },
            ),
          ),
          BottomNavigationBar(
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.people),
                label: 'User',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.sentiment_satisfied),
                label: 'Complaint',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.add),
                label: 'Edit',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.list),
                label: 'Refund',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.description),
                label: 'Report',
              ),
            ],
            onTap: (index) {
              switch (index) {
                case 0:
                  // 用户页面（当前页面）
                  break;
                case 1:
                  // 跳转到反馈页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ComplaintsPage(),
                    ),
                  );
                  break;
                case 2:
                  // 跳转到添加用户页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      //
                      builder: (context) => const ComplaintsPage(),
                    ),
                  );
                  break;
                case 3:
                  // 跳转到报告页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const RefundPage(),
                    ),
                  );
                  break;
                case 4:
                  // 跳转到文档页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ComplaintsPage(),
                    ),
                  );
                  break;
              }
            },
          ),
        ],
      ),
    );
  }
}

// 模拟用户数据
class User {
  final String name;
  final String photoUrl;
  final bool isCustomer;
  final String? description;
  final int rating;

  User({
    required this.name,
    required this.photoUrl,
    required this.isCustomer,
    this.description,
    this.rating = 0,
  });
}

// 示例用户数据
final List<User> users = [
  User(name: 'John Doe', photoUrl: 'https://via.placeholder.com/150', isCustomer: true),
  User(name: 'Jane Smith', photoUrl: 'https://via.placeholder.com/150', isCustomer: true),
  User(name: 'Alice Worker', photoUrl: 'https://via.placeholder.com/150', isCustomer: false, description: '经验丰富的清洁工', rating: 4),
  User(name: 'Bob Worker', photoUrl: 'https://via.placeholder.com/150', isCustomer: false, description: '专业的保姆', rating: 3),
];
