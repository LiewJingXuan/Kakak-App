import 'package:flutter/material.dart';
import 'login.dart';
import 'manageUser.dart';
import 'refund.dart';

class ComplaintsPage extends StatelessWidget {
  const ComplaintsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginPage()));
          },
        ),
        title: const Text('Manage Complaint'),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle),
            onPressed: () {
              // 显示当前admin的头像
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: complaints.length,
              itemBuilder: (context, index) {
                final complaint = complaints[index];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(complaint.photoUrl), // 用户头像
                  ),
                  title: Row(
                    children: [
                      Text(complaint.name),
                      const Icon(Icons.person), // 客户图标
                    ],
                  ),
                  onTap: () {
                    // 跳转到与该用户的联络页面
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ContactUserPage(
                          userId: complaint.userId,
                          name: complaint.name,
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          BottomNavigationBar(
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.people),
                label: 'User',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.sentiment_satisfied),
                label: 'Complaint',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.add),
                label: 'Edit',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.list),
                label: 'Refund',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.description),
                label: 'Report',
              ),
            ],
            onTap: (index) {
              switch (index) {
                case 0:
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ManageUsersPage(),
                    ),
                  );
                  break;
                case 1:
                  
                  break;
                case 2:
                  // 跳转到添加用户页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      //
                      builder: (context) => const ComplaintsPage(),
                    ),
                  );
                  break;
                case 3:
                  // 跳转到报告页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const RefundPage(),
                    ),
                  );
                  break;
                case 4:
                  // 跳转到文档页面
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ComplaintsPage(),
                    ),
                  );
                  break;
              }
            },
          ),
        ],
      ),
    );
  }
}

// 模拟投诉数据
class Complaint {
  final String userId;
  final String name;
  final String photoUrl;

  Complaint({
    required this.userId,
    required this.name,
    required this.photoUrl,
  });
}

// 示例投诉数据
final List<Complaint> complaints = [
  Complaint(userId: '1', name: 'John Doe', photoUrl: 'https://via.placeholder.com/150'),
  Complaint(userId: '2', name: 'Jane Smith', photoUrl: 'https://via.placeholder.com/150'),
  Complaint(userId: '3', name: 'Alice Brown', photoUrl: 'https://via.placeholder.com/150'),
];

// 用户联络页面
class ContactUserPage extends StatelessWidget {
  final String userId;
  final String name;

  ContactUserPage({required this.userId, required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('与 $name 联络'),
      ),
      body: Center(
        child: Text('这里是与 $name 的联络页面'),
      ),
    );
  }
}
