import 'package:flutter/material.dart';
import 'household_chores_page.dart';
import 'day_care_page.dart';
import 'package:mae_assignment/widgets/service_icon.dart';

class ServicesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Services"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        actions: [
          IconButton(
            icon: Image.asset('assets/blank_profile.png', width: 30),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SizedBox(height: 20),
            Text("Our Services", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text("Please Choose One Service", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ServiceIcon(
                  imagePath: 'assets/household_chores1.jpg',
                  label: "Household Chores",
                  iconSize: 120,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HouseholdChoresPage()),
                    );
                  },
                ),
                ServiceIcon(
                  imagePath: 'assets/daycare.jpg',
                  label: "Day Care",
                  iconSize: 120,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => DayCarePage()),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
