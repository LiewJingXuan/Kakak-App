import 'package:flutter/material.dart';

class ServiceIcon extends StatelessWidget {
  final String imagePath;
  final String label;
  final double iconSize;
  final VoidCallback onTap;

  ServiceIcon({required this.imagePath, required this.label, this.iconSize = 60, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Image.asset(imagePath, height: iconSize, width: iconSize),
          SizedBox(height: 5),
          Text(label),
        ],
      ),
    );
  }
}