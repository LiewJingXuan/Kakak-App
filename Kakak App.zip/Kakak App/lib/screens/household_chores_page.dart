import 'package:flutter/material.dart';
import 'workers_details_page.dart';

class HouseholdChoresPage extends StatefulWidget {
  @override
  HouseholdChoresPageState createState() => HouseholdChoresPageState();
}

class HouseholdChoresPageState extends State<HouseholdChoresPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Household Chores"),
        actions: [
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () {
              // Profile button action
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Filters Row (Date, Time, Location)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "dd/mm/yy",
                      prefixIcon: Icon(Icons.calendar_today),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Time (hh:mm am/pm)",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: "Location",
                      prefixIcon: Icon(Icons.location_on),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            
            // Search Bar
            TextField(
              decoration: InputDecoration(
                hintText: "Search for worker",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
              onChanged: (value) {
                // Implement search functionality here
              },
            ),
            SizedBox(height: 10),
            
            // Workers List
            Expanded(
              child: ListView.builder(
                itemCount: 5, // Number of workers; replace with actual data
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Container(
                      width: 60,
                      height: 60,
                      color: Colors.grey[300],
                      child: Center(child: Text("Photo")), // Placeholder for worker's photo
                    ),
                    title: Text("Worker's Name"),
                    subtitle: Text("Worker's details go here"),
                    trailing: Icon(Icons.arrow_forward),
                    onTap: () {
                      // Navigate to WorkerDetailsPage when tapped
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => WorkerDetailsPage()),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
