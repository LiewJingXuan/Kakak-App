import 'package:flutter/material.dart';
import 'booking_detail_page.dart';

class BookingHistoryPage extends StatelessWidget {
  final List<Map<String, dynamic>> bookings = [
    {"title": "Booking 1", "date": "2024-11-01", "status": "Pending"},
    {"title": "Booking 2", "date": "2024-11-02", "status": "Completed"},
    {"title": "Booking 3", "date": "2024-11-03", "status": "Pending"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Booking History"),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              // Profile action
            },
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(8),
        child: ListView.builder(
          itemCount: bookings.length,
          itemBuilder: (context, index) {
            final booking = bookings[index];
            return Card(
              margin: EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                leading: Container(
                  width: 50,
                  height: 50,
                  color: Colors.grey[300],
                  child: Center(child: Icon(Icons.image)), // Placeholder for booking image
                ),
                title: Text(booking["title"]),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Date: ${booking["date"]}"),
                    Text("Status: ${booking["status"]}"),
                  ],
                ),
                onTap: () {
                  // Navigate to BookingDetailPage with booking details
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => BookingDetailPage(booking: booking),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
