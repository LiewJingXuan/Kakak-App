import 'package:flutter/material.dart';
import 'screens/main_navigation.dart';
import 'screens/customer_dashboard.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "AIzaSyBDFXD1bSm4zuCQBNZpSttrhlsgzQAJAVk", 
      appId: "1:702304807119:android:1bc6d8d71f7474655eefba", 
      messagingSenderId: "702304807119", 
      projectId: "newmaetest")
  );

  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => MainNavigation(),
      '/customer_dashboard': (context) => CustomerDashboard(),
    },
  ));
}

class ServiceIcon extends StatelessWidget {
  final String imagePath;
  final String label;
  final double iconSize;
  final VoidCallback onTap;

  ServiceIcon({required this.imagePath, required this.label, this.iconSize = 60, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Image.asset(imagePath, height: iconSize, width: iconSize),
          SizedBox(height: 5),
          Text(label),
        ],
      ),
    );
  }
}



